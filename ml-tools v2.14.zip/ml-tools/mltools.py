import os

def main():
    os.system("clear")

    print("welcome back hacker in my tool i hope to be useful "
          "\nfor any questions you can contact with me in facebook(https://www.facebook.com/mostafa.lawati)")
    print("\n")
    print("for kile update enter (1)\n"
          "for kile upgrade enter (2)\n"
          "for install some tools (3)\n"
          "for nmap scan (4)\n"
          "for setoolkit (5)\n"
          "for kali meta-packages menu (6)\n"
          "for kali meta-packages tools (7)\n"
          "to create your word list (8)\n"
          "for bruteforce attacks (9)\n")
    print("\n")
    random()



def random():
    random_x = input(str("enter your choice : "))
    if random_x == str("1"):
        kail_update()

    if random_x == str("2"):
        kail_upgrade()

    if random_x == str("3"):
        some_tools()

    if random_x == str("4"):
        namp_scan()

    if random_x == str("5"):
        setoolkit()

    if random_x == str("6"):
        metapackages_M()

    if random_x == str("7"):
        metapackages_T()

    if random_x == str("8"):
        wordlist()

    if random_x == str("9"):
        bruteforce()


def kail_upgrade():
    print("welcome back hacker")
    upgrade = input(str("if you are want to upgrade your system enter [yes] if not enter [no] : "))
    if upgrade == str("yes"or"YES"or"Yes"):
        os.system("sudo apt-get upgrade -y")

        main()

    else:
        main()




def kail_update():
    print ("welcome back hacker")
    update = input(str("if you are want to update your system enter [yes] if not enter [no] : "))
    if update == str("yes"or"YES"or"Yes"):
        os.system("sudo apt-get update -y")
        c_upgrade = input(str("if you want to move to upgrade [yes] if not [no] : "))
        if c_upgrade == str("yes"or"Yes"or"YES"):
            kail_upgrade()

            main()
        else:
            main()
    else:
        main()


def some_tools():
    from tools import tools_main



def setoolkit():
    os.system("setoolkit")


def namp_scan():
    print("for stealth fast open tcp port and service version scan [1]\n"
          "to find all device on local network [2]\n"
          "for open tcp port scan [3]\n"
          "for open udp port scan [4]\n"
          "for open CVE Detecting [5]\n"
          "for WordPress brute force [6]\n"
          "for MS-SQL brute force [7]\n"
          "for FTP brute force [8]\n"
          "for Detecting malware [9]\n")

    scan_type = input(str("enter the type of your scan : "))

    if scan_type == str("1"):
        fast_scan()

    if scan_type == str("2"):
        local_scan()

    if scan_type == str("3"):
        TCP_scan()

    if scan_type == str("4"):
        UDP_scan()

    if scan_type == str("5"):
        CVE_scan()

    if scan_type == str("6"):
        WordPress_brute_force()

    if scan_type == str("7"):
        MS_SQL_brute_force()

    if scan_type == str("8"):
        FTP_brute_force()

    if scan_type == str("9"):
        Detecting_malware()

    else:
        namp_scan()


def local_scan():
    os.system("clear")
    os.system("ifconfig")
    print("\n")
    target = input("enter your router ip ex(192.168.0.1/24) :")
    os.system("sudo nmap -oN local-scan.txt -T4 -F ".__add__(target))
    print("\n")
    q_continue = int(input("enter 1 to scan ip  2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()
def fast_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -F -sS -sV -O " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def TCP_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sT " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def UDP_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sU " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def CVE_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -Pn --script vuln " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def WordPress_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sV --script http-wordpress-brute --script-args 'userdb=users.txt,passdb=passwds.txt,http-wordpress-brute.hostname=domain.com, http-wordpress-brute.threads=3,brute.firstonly=true'" .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def MS_SQL_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -p 1433 --script ms-sql-brute --script-args userdb=customuser.txt,passdb=custompass.txt " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def FTP_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap --script ftp-brute -p 20,21,22,26,69,115,152,989,990 " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def Detecting_malware():
    os.system("clear")
    print("for common malware scan [1] or Google’s Malware check [2] ")
    Detecting_malware_type = input("enter your detecting type : ")
    if Detecting_malware_type == "2":
        target = input("enter your target url :")
        os.system("sudo nmap -p80 --script http-google-malware ".__add__( target))

    if Detecting_malware_type == "1":
        target = input("enter your target ip :")
        os.system("sudo nmap -sV --script=http-malware-host ".__add__( target))


def metapackages_M():
    from kaliMetap_M import main

def metapackages_T():
    from kalitools import main

def wordlist():
    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))
    if word_list_type == str("custom"):
        y = input("enter your list character : ")
        x_s = str(input('start num : '))
        x_e = str(input('end num : '))
        x_t = x_s + " " + x_e +" "+y
        print(x_t)
        os.system("crunch ".__add__(x_t) + " -o custom.txt")
        os.system("echo \" your wordlist have been saved in ml-tools folder \"")
        main()
    if word_list_type == str("word"):
        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
        x_s = str(input('start num : '))
        x_e = str(input('end num : '))
        x_t = x_s + " " + x_e + y
        print(x_t)
        os.system("crunch ".__add__(x_t) + " -o word.txt")
        os.system("echo \" your wordlist have been saved in ml-tools folder \"")
        main()

    else:
        main()

def bruteforce():

    user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

    def user_as_list():
        userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
        target_ip = str(input("enter your target IP : "))
        rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

        def ftp_attack():
            os.system("hydra -s 22 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")

        def custom_word_list():
            q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
            if q_for_wordlist == str('have'):
                wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")

            if q_for_wordlist == str("make"):
                word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                if word_list_type == str("custom"):
                    y = input("enter your list character : ")
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + " " + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o custom.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")

                if word_list_type == str("word"):
                    y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o word.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")

        if rockyou_Q == str("no"):
            os.system("cd /usr/share/wordlists")
            os.system("gzip -dv rockyou.txt.gz")
            ftp_attack()

        if rockyou_Q == str("yes"):
            ftp_attack()

        if rockyou_Q == str("custom"):
            custom_word_list()

        else:
            bruteforce()

    def user_UnKown():
        target_ip = str(input("enter your target IP : "))
        rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

        def ftp_attack():
            os.system("hydra -s 22 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

        def custom_word_list():
            q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
            if q_for_wordlist == str('have'):
                wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

            if q_for_wordlist == str("make"):
                word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                if word_list_type == str("custom"):
                    y = input("enter your list character : ")
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + " " + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o custom.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

                if word_list_type == str("word"):
                    y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o word.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

        if rockyou_Q == str("no"):
            os.system("cd /usr/share/wordlists")
            os.system("gzip -dv rockyou.txt.gz")
            ftp_attack()

        if rockyou_Q == str("yes"):
            ftp_attack()

        if rockyou_Q == str("custom"):
            custom_word_list()

        else:
            bruteforce()

    def user_know():
        user= str(input( "enter the user name : "))
        target_ip = str(input("enter your target IP : "))
        rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
        def ftp_attack():
            os.system("hydra -s 22 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserKnow.txt ".__add__(target_ip)+" ssh")

        def custom_word_list():
            q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
            if q_for_wordlist == str('have'):
                wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

            if q_for_wordlist == str("make"):
                word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                if word_list_type == str("custom"):
                    y = input("enter your list character : ")
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + " " + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o custom.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

                if word_list_type == str("word"):
                    y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                    x_s = str(input('start num : '))
                    x_e = str(input('end num : '))
                    x_t = x_s + " " + x_e + y
                    print(x_t)
                    os.system("crunch ".__add__(x_t) + " -o word.txt")
                    os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")

        if rockyou_Q == str("no"):
            os.system("cd /usr/share/wordlists")
            os.system("gzip -dv rockyou.txt.gz")
            ftp_attack()

        if rockyou_Q == str("yes"):
            ftp_attack()

        if rockyou_Q == str("custom"):
            custom_word_list()

        else:
            bruteforce()

    if user_name_Q == str("userK"):
        user_know()

    if user_name_Q == str("userx"):
        user_UnKown()

    if user_name_Q == str("list"):
        user_as_list()

main()