import os
def main():
    os.system("clear")
    print("for information gathering menu (1)\n"
          "for vulnerability menu (2)\n"
          "for web pentest menu (3)\n"
          "for database menu (4)\n"
          "for passwords menu (5)\n"
          "for wireless menu (6)\n"
          "for reverse engineering menu (7)\n"
          "for exploitation menu (8)\n"
          "for social engineering menu (9)\n"
          "for sniffing and spoofing menu (10)\n"
          "for post exploitation menu (11)\n"
          "for forensics menu (12)\n"
          "for reporting menu (13)\n"
          "for all menu (14)\n"
          "to back to main menu (00)\n")
    choice()

def choice():
    c_random = int(input("enter your choice : "))
    if c_random == 1:
        information_gathering()

    if c_random == 2:
        vulnerability_tools()

    if c_random == 3:
        web_pentest()

    if c_random == 4:
        database_tools()

    if c_random == 5:
        passwords_tools()

    if c_random == 6:
        wireless_tools()

    if c_random == 7:
        reverse_engineering()

    if c_random == 8:
        exploitation_tools()

    if c_random == 9:
        social_engineering()

    if c_random == 10:
        sniffing_spoofing()

    if c_random == 11:
        post_exploitation()

    if c_random == 12:
        forensics()

    if c_random == 13:
        reporting()

    if c_random == 14:
        All()

    if c_random == 00:
        main_menu()


def information_gathering():
    c_input = str(input("if you want to install information gathering menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-information-gathering -y")
        main()
    else:
        main()

def vulnerability_tools():
    c_input = str(input("if you want to install vulnerability menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-vulnerability -y")
        main()
    else:
        main()
def web_pentest():
    c_input = str(input("if you want to install web pentest menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-web -y")
        main()
    else:
        main()

def database_tools():
    c_input = str(input("if you want to install database menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-database -y")
        main()
    else:
        main()

def passwords_tools():
    c_input = str(input("if you want to install passwords menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-passwords -y")
        main()
    else:
        main()

def wireless_tools():
    c_input = str(input("if you want to install wireless menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-wireless -y")
        main()
    else:
        main()

def reverse_engineering():
    c_input = str(input("if you want to install reverse engineering menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-reverse-engineering -y")
        main()
    else:
        main()

def exploitation_tools():
    c_input = str(input("if you want to install exploitation menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-exploitation -y")
        main()
    else:
        main()

def sniffing_spoofing():
    c_input = str(input("if you want to install sniffing and spoofing menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-sniffing-spoofing -y")
        main()
    else:
        main()

def social_engineering():
    c_input = str(input("if you want to install social engineering menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-social-engineering -y")
        main()
    else:
        main()

def post_exploitation():
    c_input = str(input("if you want to install post exploitation menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-post-exploitation -y")
        main()
    else:
        main()

def forensics():
    c_input = str(input("if you want to install forensics menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-forensics -y")
        main()
    else:
        main()

def reporting():
    c_input = str(input("if you want to install reporting menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-reporting -y")
        main()
    else:
        main()

def All():
    c_input = str(input("if you want to install all menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt update -y && sudo apt install kali-tools-reporting -y && sudo apt install kali-tools-forensics -y && sudo apt install kali-tools-post-exploitation -y && sudo apt install kali-tools-sniffing-spoofing -y && sudo apt install kali-tools-social-engineering -y && sudo apt install kali-tools-exploitation -y && sudo apt install kali-tools-reverse-engineering -y && sudo apt install kali-tools-wireless -y && sudo apt install kali-tools-passwords -y && sudo apt install kali-tools-database -y && sudo apt install kali-tools-web -y && sudo apt install kali-tools-vulnerability -y && sudo apt install kali-tools-information-gathering -y ")
        main()
    else:
        main()
def main_menu():
    from mltools import main

main()